## Activity description
The student will not need to develop any code for this assignment, but instead will execute the Dining Philosophers code.

## Assignment Instructions
1. M​odify the code as you see fit.  It is currently written as the solution for the problem, available at https://rosettacode.org/wiki/Dining_philosophers#Python.
2. R​un the code via python3 dining_philosophers.py. Note that it will not complete without the user using a Keyboard Interrupt (such as CTRL-C or CTRL-Z).
3. The currently written code will only allow you to get an 80% grade, which is passing. If you want to get 100%, it will need to complete without human intervention.