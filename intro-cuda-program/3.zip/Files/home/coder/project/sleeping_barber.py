# Based on code from https://github.com/Nohclu/Sleeping-Barber-Python-3.6-/blob/master/barber.py
import time
import random
import threading
from queue import Queue

CUSTOMERS_SEATS = 15        # Number of seats in BarberShop
BARBERS = 3                # Number of Barbers working
EVENT = threading.Event()   # Event flag, keeps track of Barber/Customer interactions
global Earnings
global SHOP_OPEN


class Customer(threading.Thread):       # Producer Thread
    def __init__(self, queue):          # Constructor passes Global Queue (all_customers) to Class
        threading.Thread.__init__(self)
        self.queue = queue
        self.rate = self.what_customer()

    @staticmethod
    def what_customer():
        customer_types = ["adult", "senior", "student", "child"]
        customer_rates = {"adult": 16,
                          "senior": 7,
                          "student": 10,
                          "child": 7}
        t = random.choice(customer_types)
        print(t + " rate.")
        return customer_rates[t]

    def run(self):
        if not self.queue.full():  # Check queue size
            EVENT.set()  # Sets EVENT flag to True i.e. Customer available in the Queue
            EVENT.clear()  # Alerts Barber that their is a Customer available in the Queue
        else:
            # If Queue is full, Customer leaves.
            print("Queue full, customer has left.")

    def trim(self):
        print("Customer haircut started.")
        a = 3 * random.random()  # Retrieves random number.
        # Execute the time sleep function with a, which simulates the time it takes for a barber to give a haircut.
        time.sleep(a)
        payment = self.rate
        # Barber finished haircut.
        print("Haircut finished. Haircut took {:.2f} seconds".format(a))
        global Earnings
        Earnings += payment


class Barber(threading.Thread):     # Consumer Thread
    def __init__(self, queue):      # Constructor passes Global Queue (all_customers) to Class
        threading.Thread.__init__(self)
        # Set this class's queue property to the passed value
        self.queue = queue
        self.sleep = True   # No Customers in Queue therefore Barber sleeps by default

    def is_empty(self):  # Simple function that checks if there is a customer in the Queue and if so
        if self.queue.empty():
            self.sleep = True   # If nobody in the Queue Barber sleeps.
        else:
            self.sleep = False  # Else he wakes up.
        print("------------------\nBarber sleep {}\n------------------".format(self.sleep))

    def run(self):
        global SHOP_OPEN
        while SHOP_OPEN:
            while self.queue.empty():
                # Waits for the Event flag to be set, Can be seen as the Barber Actually sleeping.
                EVENT.wait()
                print("Barber is sleeping...")
                if not SHOP_OPEN:  # Check if shop is still open
                    break
            if not SHOP_OPEN:  # Exit if shop is closed
                break
            print("Barber is awake.")
            if not self.queue.empty():
                self.is_empty()
                # FIFO Queue So first customer added is gotten.
                customer = self.queue.get()
                customer.trim()  # Customers Hair is being cut
                # Use the task_done function to complete cutting the customer's hair
                self.queue.task_done()
                print(f"Barber {self.name} served the customer")    # Which Barber served the Customer


def wait():
    time.sleep(1 * random.random())


if __name__ == '__main__':
    Earnings = 0
    SHOP_OPEN = True
    barbers = []
    all_customers = Queue(CUSTOMERS_SEATS)  # A queue of size Customer Seats

    for b in range(BARBERS):
        # Pass the all_customers Queue to the Barber constructor
        barber = Barber(all_customers)
        # Makes the Thread a super low priority thread allowing it to be terminated easier
        barber.daemon = True
        barber.start()   # Invokes the run method in the Barber Class
        # Adding the Barber Thread to an array for easy referencing later on.
        barbers.append(barber)
    
    for c in range(10):  # Loop that creates 10 Customers
        print("----")
        # Simple Tracker too see the qsize (NOT RELIABLE!)
        print(f"Queue size: {all_customers.qsize()}")
        wait()
        customer = Customer(all_customers)  # Passing Queue object to Customer class
        all_customers.put(customer)    # Puts the Customer Thread in the Queue
        # Invoke the run method in the Customer Class
        customer.start()
    
    # Wait for all customers to be served
    all_customers.join()    # Terminates all Customer Threads
    print("Total Earnings: €" + str(Earnings))
    SHOP_OPEN = False
    EVENT.set()  # Wake up sleeping barbers so they can exit
    
    for barber in barbers:
        barber.join()    # Terminates all Barbers